import { ApolloClient, InMemoryCache, HttpLink } from "@apollo/client";
import client, { httpLink } from "../apollo_client"

describe("Apollo Client Setup", () => {
  it("should be an instance of ApolloClient", () => {
    expect(client).toBeInstanceOf(ApolloClient);
  });

  it("should have HttpLink with correct URI", () => {
    expect(httpLink).toBeInstanceOf(HttpLink);
  });

  it("should use InMemoryCache instance", () => {
    expect(client.cache).toBeInstanceOf(InMemoryCache);
  });
});
