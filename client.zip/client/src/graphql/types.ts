// types.ts or inside App.tsx

interface Button {
  text: string;
  variant: "solid" | "outline";
}

interface HeroBannerData {
  image: string;
  subtitle: string;
  title: string;
  description: string;
  buttons: Button[];
}

interface ProductCard {
  title: string;
  text: string;
  img: string;
  buttons: Button[];
}

export interface GetHeroAndProductsData {
  heroBanner: HeroBannerData;
  productCards: ProductCard[];
}
