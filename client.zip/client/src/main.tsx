// src/index.tsx
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ApolloProvider } from '@apollo/client/react';
import client from './graphql/apollo_client.ts'; // Adjust path if needed
import App from './App.tsx';
import './index.css';
// import { gql } from "@apollo/client";
// import { useQuery } from "@apollo/client/react";
const root = createRoot(document.getElementById('root')!);

root.render(
  <StrictMode>
    <ApolloProvider client={client}>
      <App />
    </ApolloProvider>
  </StrictMode>
);
