import React from "react";
import ProductCard from "./ProductCard";

interface ProductCardType {
  title: string;
  text: string;
  img: string;
  buttons: { text: string; variant: "solid" | "outline" }[];
}

interface ProductCardsProps {
  cards: ProductCardType[];
}

const ProductCards: React.FC<ProductCardsProps> = ({ cards }) => {
  return (
    <div className="max-w-7xl mx-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
      {cards.map((card, idx) => (
        <ProductCard key={idx} {...card} isFirst={idx === 0} />
      ))}
    </div>
  );
};``

export default ProductCards;
