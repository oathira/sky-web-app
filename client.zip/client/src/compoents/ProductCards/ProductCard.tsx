import React from "react";

interface ButtonProps {
  text: string;
  variant: "solid" | "outline";
}

interface ProductCardProps {
  title: string;
  text: string;
  img: string;
  buttons: ButtonProps[];
  isFirst?: boolean; // add a prop for layout control
}

const ProductCard: React.FC<ProductCardProps> = ({ title, text, img, buttons, isFirst }) => {
  if (isFirst) {
    // First card special layout
    return (
      <div
        className={`relative rounded-2xl shadow-lg overflow-hidden ${isFirst ? "col-span-2" : ""}`}
      >
        {/* Full-size image */}
        <img src={img} alt={title} className="w-full h-full object-contain" />

        {/* Overlay text/buttons */}
        <div className="absolute inset-0 flex flex-col justify-center p-6 gap-3 text-black">
          <h2 className={`text-xl font-bold ${isFirst ? "md:text-3xl" : "md:text-xl"}`}>
            {title}
          </h2>
          <p className={`${isFirst ? "md:text-lg" : "md:text-sm"}`}>{text}</p>
          <div className="flex gap-3 mt-4 flex-wrap">
            {buttons.map((btn, i) => (
              <button
                key={i}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  btn.variant === "solid"
                    ? "bg-blue-600 text-white hover:bg-blue-700"
                    : "border border-blue-600 text-blue-600"
                }`}
              >
                {btn.text}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Default layout
  return (
    <div className="relative rounded-2xl shadow-lg overflow-hidden">
      {/* Image */}
      <img src={img} alt={title} className="w-full h-full w-full h-full object-contain" />

      {/* Overlay text and buttons */}
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 mt-6 flex flex-col items-center gap-3 text-center text-black">
        <h2 className="text-2xl font-bold">{title}</h2>
        <p className="text-base">{text}</p>
        <div className="flex gap-3 mt-4">
          {buttons.map((btn, i) => (
            <button
              key={i}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                btn.variant === "solid"
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "border border-blue-600 text-blue-600"
              }`}
            >
              {btn.text}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
