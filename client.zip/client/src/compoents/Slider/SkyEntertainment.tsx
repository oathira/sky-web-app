import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

const shows = [
  {
    id: "1",
    title: "Brassic",
    description: "The Final Farewell",
    image:
      "https://static.skyassets.com/contentstack/assets/blt143e20b03d72047e/blt06d32328ae4eda1e/68d11283d4859e7ba731d050/HL_KA_04_Brassic_S07.jpg?format=webp&imageManager=true&impolicy=resize&width=1280",
  },
  {
    id: "2",
    title: "Atomic",
    description: "One Hell of a Ride",
    image:
      "https://static.skyassets.com/contentstack/assets/blt143e20b03d72047e/blt2fc579e014df18bd/68befeeac6351b5ebc14304c/KA_03_Atomic_S01.jpg?format=webp&imageManager=true&impolicy=resize&width=1280",
  },
  {
    id: "3",
    title: "Task",
    description: "Available now",
    image:
      "https://static.skyassets.com/contentstack/assets/blt143e20b03d72047e/blt4ae88e25f8396edd/68beff604405f48817a7eef6/KA_02_UI_Task_S01.jpg?format=webp&imageManager=true&impolicy=resize&width=1280",
  },
  {
    id: "4",
    title: "Another Show",
    description: "Coming soon...",
    image:
      "https://static.skyassets.com/contentstack/assets/blt143e20b03d72047e/bltaf8eb57c20d5bfe0/68beffba74616525e4c3244b/KA_03_ThePaper_Newspaper.jpg?format=webp&imageManager=true&impolicy=resize&width=1280",
  },
];

export default function SkyEntertainment() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev === 0 ? shows.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev === shows.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="bg-blue-900 text-white py-10">
      <h2 className="text-center text-2xl font-semibold mb-6">
        Sky Entertainment
      </h2>

      <div className="relative max-w-5xl mx-auto overflow-hidden">
        {/* Slider */}
        <div
          className="flex transition-transform duration-500"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {shows.map((show) => (
            <div key={show.id} className="min-w-full flex-shrink-0 px-4">
              <div className="rounded-2xl shadow-lg overflow-hidden">
                <img
                  src={show.image}
                  alt={show.title}
                  className="w-full h-60 sm:h-72 md:h-80 object-cover "
                />
                <div className="p-4">
                  <h3 className="font-bold">{show.title}</h3>
                  <p className="text-sm">{show.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation arrows below slider */}
        <div className="flex justify-center gap-4 mt-6">
          <button
            onClick={prevSlide}
            className="bg-white text-black p-2 shadow "
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={nextSlide}
            className="bg-white text-black p-2  shadow "
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}
