import { useState } from "react";
import { Bell, Search } from 'lucide-react';

import sky from "../../assets/sky.png";

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { name: "Watch" },
    { name: "TV" },
    { name: "Glass" },
    { name: "Broadband" },
    { name: "Mobile" },
    { name: "Protect" },
    { name: "Business" },
    { name: "Deals" },
  ];

  return (
    <nav className="w-full h-12 flex items-center justify-between px-4 shadow-sm  sky-border bg-white relative">
      {/* Mobile Left - Hamburger */}
      <button
        className="md:hidden text-2xl"
        onClick={() => setMenuOpen(!menuOpen)}
      >
        ☰
      </button>

      {/* Center Logo */}
      <img src={sky} alt="skylpgo" className="h-6 w-auto" />

      {/* Right - Sign in (mobile) */}
      <button className="md:hidden  text-sm hover:underline">
        Sign in
      </button>

      {/* Desktop Nav */}
      <div className="hidden md:flex items-center justify-between flex-1 ml-8 mr-8">
        <ul className="flex space-x-6 font-skytext-sans text-sm font-sm ">
          {navItems.map((item, idx) => (
            <li key={idx} className="relative cursor-pointer hover:underline flex items-center">
              {item.name}
              {/* Dropdown icon always visible */}
              <svg
                className="ml-3 w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </li>
          ))}
        </ul>

        {/* Right Actions */}
        <div className="flex items-center space-x-5  ">
         <Search size={20} strokeWidth={0.75} />
          <Bell strokeWidth={0.80} />

          {/* Help */}
          <span className="flex text-sm items-center cursor-pointer hover:underline">
            Help
            <svg
              className="ml-3 w-3 h-3"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </span>

          {/* Sign in */}
          <span className="flex items-center cursor-pointer hover:underline text-sm">
            Sign in
          </span>
        </div>
      </div>

      {/* Mobile Slide-Out Menu */}
      {menuOpen && (
        <div className="absolute top-12 left-0 w-64 h-screen bg-white shadow-lg border-r z-50 p-4 md:hidden">
          <ul className="space-y-4 ">
            {navItems.map((item, idx) => (
              <li key={idx} className="hover:underline cursor-pointer">
                {item.name}
              </li>
            ))}
            <li className="hover:underline">Help</li>
            <li className="hover:underline">Search 🔍</li>
          </ul>
        </div>
      )}
    </nav>
  );
}
