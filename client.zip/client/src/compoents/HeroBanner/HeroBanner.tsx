import React from "react";

export interface Button {
  text: string;
  variant: "solid" | "outline";
}

export interface HeroBannerProps {
  image: string;
  subtitle: string;
  title: string;
  description: string;
  buttons: Button[];
}

const HeroBanner: React.FC<HeroBannerProps> = ({
  image,
  subtitle,
  title,
  description,
  buttons,
}) => {
  return (
    <div className="relative w-full h-[450px] md:h-[550px] text-white">
      <img
        src={image}
        alt={title}
        className="absolute inset-0 w-full h-full object-cover"
      />
     

      <div className="relative z-10 h-full flex items-center px-6 md:px-16">
        <div className="max-w-lg text-center mx-auto">
          <p className="text-sm">{subtitle}</p>
          <h1 className="text-3xl md:text-4xl font-bold leading-tight mt-2">
            {title}
          </h1>
          <p className="mt-4 text-lg text-gray-200">{description}</p>

          <div className="mt-6 flex justify-center gap-4 flex-wrap">
            {buttons.map((btn, idx) => (
              <button
                key={idx}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                  btn.variant === "solid"
                    ? "bg-blue-600 text-white hover:bg-blue-700"
                    : "border border-white-600 text-white-600"
                }`}
              >
                {btn.text}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;
