// filepath: c:\Users\sruth\my-project\src\setupTests.ts
import '@testing-library/jest-dom'; // Adds custom jest matchers for DOM nodes