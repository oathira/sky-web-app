import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@as-integrations/express5';

import { typeDefs } from './graphql/schema.ts';
import { resolvers } from './graphql/resolvers.ts';

// Recreate __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();

  const server = new ApolloServer({
    typeDefs,
    resolvers,
  });

  await server.start();

  app.use(cors());
  app.use(express.json());

  app.use('/public', express.static(path.join(__dirname, '../public')));

  app.use('/graphql', expressMiddleware(server));

  app.listen(4000, () => {
    console.log('Server ready at http://localhost:4000/graphql');
    console.log('Static files served at http://localhost:4000/public');
  });
}

startServer().catch(console.error);
