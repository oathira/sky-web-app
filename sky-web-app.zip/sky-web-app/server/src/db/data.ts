
export const heroBanner = {
img: "http://localhost:4000/public/hrobanner.jpeg",
  subtitle: "Our lowest price is back",
  title: "Sky Essential TV & Sky Full Fibre",
  description:
    "Sky, Netflix and discovery+, supercharged with 800Mbps Full Fibre Broadband for just £28/month",
  buttons: [
    { text: "Buy now", variant: "solid" },
    { text: "See all deals", variant: "outline" },
  ],
};

export const productCards = [
  {
    title: "Sky Sports",
    text: "An unmissable October. All 8 dedicated sports channels, including Premier League, F1 and more. Includes Sky Sports+.",
    img: "https://yourdomain.com/sky-sports.jpg",
    buttons: [
      { text: "See all deals", variant: "outline" },
      { text: "Buy now", variant: "solid" },
    ],
    span: "md:col-span-2",
  },
  {
    title: "Sky Mobile",
    text: "Available now from £35 a month. Pair with Unlimited Data for just £10 extra a month – our lowest ever price.",
    img: "https://yourdomain.com/sky-mobile.jpg",
    buttons: [
      { text: "See all deals", variant: "outline" },
      { text: "Buy now", variant: "solid" },
    ],
  },
  {
    title: "Sky Glass Air TV",
    text: "The smarter TV range just got better.",
    img: "https://yourdomain.com/sky-glass.jpg",
    buttons: [
      { text: "Learn more", variant: "outline" },
      { text: "Buy now", variant: "solid" },
    ],
  },
  {
    title: "Sky Broadband",
    text: "The UK’s fastest broadband speeds from any major provider.",
    img: "https://yourdomain.com/sky-broadband.jpg",
    buttons: [
      { text: "Learn more", variant: "outline" },
      { text: "Buy now", variant: "solid" },
    ],
  },
  {
    title: "Sky Essential TV",
    text: "Sky TV’s lowest ever price. Discover extraordinary TV with Sky, Netflix and Discovery+.",
    img: "https://yourdomain.com/sky-essential.jpg",
    buttons: [
      { text: "Learn more", variant: "outline" },
      { text: "Get started", variant: "solid" },
    ],
  },
];
