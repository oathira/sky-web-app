export interface Category {
    id: string;
    name: string;
}

export interface Product {
    id: string;
    name: string;
    price: number;
    description?: string | undefined;
    inStock: boolean;
    categoryId: string;
}

export interface GetProductByIdArgs {
    id: string;
}

export interface AddProductArgs {
    name: string;
    price: number;
    description?: string;
    inStock: boolean;
    categoryId: string;
}

export interface UpdateProductArgs {
    id: string;
    name?: string;
    price?: number;
    description?: string;
    inStock?: boolean;
    categoryId?: string;
}

export interface DeleteProductArgs {
    id: string;
}
