
export const typeDefs = `#graphql
  type Button {
    text: String!
    variant: String!
  }

  type HeroBanner {
    image: String
    subtitle: String!
    title: String!
    description: String!
    buttons: [Button!]!
  }

  type ProductCard {
    title: String!
    text: String!
    img: String!
    buttons: [Button!]!
    span: String
  }

  type Query {
    heroBanner: HeroBanner!
    productCards: [ProductCard!]!
  }
`;
