import { heroBanner, productCards } from '../db/data.ts'

export const resolvers = {
  Query: {
    heroBanner: () => heroBanner,
    productCards: () => productCards,
  },
};
