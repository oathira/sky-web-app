import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config'; // Use vitest/config instead of vite

export default defineConfig({
  plugins: [react(), tailwindcss()],
  test: {
    globals: true,
    environment: 'jsdom', // Simulates a browser-like environment
    setupFiles: './src/setupTests.ts', // Global setup for tests
    coverage: {
      reporter: ['text', 'json', 'html'], // Generates coverage reports
      exclude: ['node_modules/', 'src/setupTests.ts'], // Exclude setup files
    },
  },
});