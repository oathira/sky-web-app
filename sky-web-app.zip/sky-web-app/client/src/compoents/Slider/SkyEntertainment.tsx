

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

const shows = [
  {
    id: "1",
    title: "Brassic",
    description: "The Final Farewell",
    image: "/images/brassic.jpg",
  },
  {
    id: "2",
    title: "Atomic",
    description: "One Hell of a Ride",
    image: "/images/atomic.jpg",
  },
  {
    id: "3",
    title: "Task",
    description: "Available now",
    image: "/images/task.jpg",
  },
  {
    id: "4",
    title: "Another Show",
    description: "Coming soon...",
    image: "/images/another.jpg",
  },
];

export default function SkyEntertainment() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevSlide = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? shows.length - 1 : prev - 1
    );
  };

  const nextSlide = () => {
    setCurrentIndex((prev) =>
      prev === shows.length - 1 ? 0 : prev + 1
    );
  };

  return (
    <section className="bg-blue-900 text-white py-10">
      <h2 className="text-center text-2xl font-semibold mb-6">
        Sky Entertainment
      </h2>

      <div className="relative max-w-5xl mx-auto overflow-hidden">
        <div
          className="flex transition-transform duration-500"
          style={{
            transform: `translateX(-${currentIndex * 100}%)`,
          }}
        >
          {shows.map((show) => (
            <div
              key={show.id}
              className="min-w-full flex-shrink-0 px-4"
            >
              <div className="bg-gray-800 rounded-2xl shadow-lg overflow-hidden">
                <img
                  src={show.image}
                  alt={show.title}
                  className="w-full h-60 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-bold">{show.title}</h3>
                  <p className="text-sm">{show.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Left Arrow */}
        <button
          onClick={prevSlide}
          className="absolute top-1/2 left-4 -translate-y-1/2 bg-white text-black p-2 rounded-full shadow hover:bg-gray-200"
        >
          <ChevronLeft size={20} />
        </button>

        {/* Right Arrow */}
        <button
          onClick={nextSlide}
          className="absolute top-1/2 right-4 -translate-y-1/2 bg-white text-black p-2 rounded-full shadow hover:bg-gray-200"
        >
          <ChevronRight size={20} />
        </button>
      </div>
    </section>
  );
}
