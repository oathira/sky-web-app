import sky from "../../assets/sky.png";

export default function Footer() {
  return (
    <footer className="bg-white text-gray-700 border-t mt-10">
      {/* Legal Bit Dropdown */}
      <div className="max-w-6xl mx-auto px-6 py-6">
        <details className="border rounded-md p-4 cursor-pointer">
          <summary className="font-medium">Here&apos;s the legal bit</summary>
          <p className="mt-2 text-sm text-gray-600">
            This is where you can put your disclaimer, company policy, or legal text.
          </p>
        </details>
      </div>

      {/* Footer Links */}
      <div className="border-t">
        <div className="max-w-6xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
          {/* Left Section - Logo & Copyright */}
          <div className="flex items-center gap-2">
            <img src={sky} alt="Sky Logo" className="h-5" />
            <span>© 2025 Sky UK</span>
          </div>

          {/* Middle Section - Links */}
          <div className="flex flex-wrap justify-center gap-4">
            <a href="#" className="hover:underline">Privacy options</a>
            <a href="#" className="hover:underline">Terms & conditions</a>
            <a href="#" className="hover:underline">Privacy & cookies notice</a>
            <a href="#" className="hover:underline">Accessibility</a>
            <a href="#" className="hover:underline">Site map</a>
            <a href="#" className="hover:underline">Contact us</a>
            <a href="#" className="hover:underline">Complaints</a>
            <a href="#" className="hover:underline">Sky Group</a>
            <a href="#" className="hover:underline">Store locator</a>
          </div>

          {/* Right Section - Country Dropdown */}
          <div>
            <select className="border rounded px-2 py-1 text-sm">
              <option>Country</option>
              <option>UK</option>
              <option>India</option>
              <option>US</option>
            </select>
          </div>
        </div>
      </div>
    </footer>
  );
}
