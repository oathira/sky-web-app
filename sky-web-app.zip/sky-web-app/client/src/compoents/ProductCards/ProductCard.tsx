
import Button from "./Button";

interface ProductCardProps {
  title: string;
  text: string;
  img: string;
  buttons: { text: string; variant: "solid" | "outline" }[];
  span?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({ title, text, img, buttons, span }) => {
  return (
    <div
      className={`bg-white shadow-lg rounded-xl overflow-hidden flex flex-col ${span || ""}`}
    >
      <div className="p-5 flex justify-center flex-col flex-1">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        <p className="text-gray-600 mt-2 flex-1">{text}</p>
        <div className="flex gap-3 mt-4 flex-wrap">
          {buttons.map((btn, idx) => (
            <Button key={idx} text={btn.text} variant={btn.variant} />
          ))}
        </div>
      </div>
      <img src={img} alt={title} className="w-full h-48 md:h-56 object-cover" />
    </div>
  );
};

export default ProductCard;
