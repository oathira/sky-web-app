// client/src/graphql/queries.ts
import { gql } from "@apollo/client";

export const GET_HERO_AND_PRODUCTS = gql`
  query GetHeroAndProducts {
    heroBanner {
      image
      subtitle
      title
      description
      buttons {
        text
        variant
      }
    }
    productCards {
      title
      text
      img
      buttons {
        text
        variant
      }
      span
    }
  }
`;
