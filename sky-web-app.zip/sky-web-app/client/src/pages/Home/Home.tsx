import React from "react";
import Header from "../../compoents/Header/Header";
import HeroBanner from "../../compoents/HeroBanner/HeroBanner";
import Footer from "../../compoents/Footer/Footer";
import SkyEntertainment from "../../compoents/Slider/SkyEntertainment";
import ProductCards from "../../compoents/ProductCards/ProductCards";
import { useQuery } from "@apollo/client/react";
import { GET_HERO_AND_PRODUCTS } from "../../graphql/queries";
import type { GetHeroAndProductsData } from "../../graphql/types";

const Home: React.FC = () => {
  const { loading, error, data } = useQuery<GetHeroAndProductsData>(GET_HERO_AND_PRODUCTS);

  return (
    <div>
      <Header />

      {loading && <p className="text-center my-6">Loading...</p>}
      {error && <p className="text-center text-red-500 my-6">Error loading content.</p>}

      {!loading && !error && data && (
        <>
          <HeroBanner {...data.heroBanner} />
          <ProductCards cards={data.productCards} />
        </>
      )}

      <SkyEntertainment />
      <Footer />
    </div>
  );
};

export default Home;
